<?php
// Ambil ID Pasien dari parameter GET jika ada
$id_prefill = isset($_GET['id_pasien']) ? htmlspecialchars($_GET['id_pasien']) : '';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Pasien</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
        }
        label {
            font-weight: bold;
        }
        input[type="text"] {
            width: 300px;
            padding: 6px;
        }
        input[type="submit"] {
            padding: 8px 16px;
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
        }
        a {
            text-decoration: none;
            color: #007bff;
        }
    </style>
</head>
<body>
    <h2>Form Tambah Pasien</h2>
    
    <form action="simpan_pasien.php" method="post">
        <input type="hidden" name="redirect" value="form_rekam.php">
        
        <label for="id_pasien">ID Pasien:</label><br>
        <input type="text" id="id_pasien" name="id_pasien" required value="<?= $id_prefill ?>"><br><br>

        <label for="nama">Nama Pasien:</label><br>
        <input type="text" id="nama" name="nama" required><br><br>

        <input type="submit" value="Simpan">
    </form>

    <br>
    <a href="form_rekam.php">← Kembali ke Form Rekam Medis</a>
</body>
</html>
