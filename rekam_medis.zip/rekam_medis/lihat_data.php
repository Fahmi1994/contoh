<?php
$conn = new mysqli("localhost", "root", "", "rs_aulia");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM rekam_medis");

echo "<h2>Data Rekam Medis</h2>";
echo "<a href='form_rekam.php'>Tambah Data Baru</a><br><br>";

if ($result->num_rows > 0) {
    echo "<table border='1' cellpadding='10'>
            <tr>
                <th>ID</th>
                <th>ID Pasien</th>
                <th>Keluhan</th>
                <th>Diagnosa</th>
            </tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>".$row['id']."</td>
                <td>".$row['id_pasien']."</td>
                <td>".$row['keluhan']."</td>
                <td>".$row['diagnosa']."</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "Belum ada data.";
}

$conn->close();
?>
