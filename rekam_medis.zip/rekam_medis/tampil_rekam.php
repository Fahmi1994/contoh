<?php
include "koneksi.php";

// Ambil data rekam medis dengan data pasien
$query = "SELECT p.nama, p.umur, r.tanggal, r.keluhan, r.diagnosa, r.obat
          FROM rekam_medis r 
          JOIN pasien p ON r.id_pasien = p.id_pasien
          ORDER BY r.tanggal DESC";

$data = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Rekam Medis</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 40px;
      background-color: #f8f8f8;
    }
    h2 {
      text-align: center;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      background-color: white;
    }
    th, td {
      border: 1px solid #ddd;
      padding: 10px;
      text-align: left;
    }
    th {
      background-color: #4CAF50;
      color: white;
    }
    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>

<h2>Data Rekam Medis</h2>

<table>
  <thead>
    <tr>
      <th>Nama Pasien</th>
      <th>Umur</th>
      <th>Tanggal</th>
      <th>Keluhan</th>
      <th>Diagnosa</th>
      <th>Obat</th>
    </tr>
  </thead>
  <tbody>
    <?php if ($data->num_rows > 0): ?>
      <?php while ($row = $data->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['nama']) ?></td>
          <td><?= htmlspecialchars($row['umur']) ?> tahun</td>
          <td><?= date('d-m-Y', strtotime($row['tanggal'])) ?></td>
          <td><?= htmlspecialchars($row['keluhan']) ?></td>
          <td><?= htmlspecialchars($row['diagnosa']) ?></td>
          <td><?= htmlspecialchars($row['obat']) ?></td>
        </tr>
      <?php endwhile; ?>
    <?php else: ?>
      <tr>
        <td colspan="6" style="text-align:center;">Tidak ada data rekam medis.</td>
      </tr>
    <?php endif; ?>
  </tbody>
</table>

</body>
</html>
