<?php include "koneksi.php"; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Form Rekam Medis</title>
</head>
<body>
    <h2>Rekam Medis Rs Andika</h2>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nama_pasien = trim($_POST['nama_pasien']);
        $tanggal = $_POST['tanggal'];
        $keluhan = $_POST['keluhan'];
        $diagnosa = $_POST['diagnosa'];
        $obat = $_POST['obat'];

        // Cek apakah pasien sudah ada
        $stmt = $conn->prepare("SELECT id_pasien FROM pasien WHERE nama_pasien = ?");
        $stmt->bind_param("s", $nama_pasien);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Pasien sudah ada
            $row = $result->fetch_assoc();
            $id_pasien = $row['id_pasien'];
        } else {
            // Tambahkan pasien baru
            $insert = $conn->prepare("INSERT INTO pasien (nama_pasien) VALUES (?)");
            $insert->bind_param("s", $nama_pasien);
            $insert->execute();
            $id_pasien = $insert->insert_id;
        }

        // Simpan data rekam medis
        $sql = "INSERT INTO rekam_medis (id_pasien, tanggal, keluhan, diagnosa, obat)
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("issss", $id_pasien, $tanggal, $keluhan, $diagnosa, $obat);

        if ($stmt->execute()) {
            echo "<p style='color:green'>✅ Data berhasil disimpan.</p>";
        } else {
            echo "<p style='color:red'>❌ Gagal menyimpan data.</p>";
        }
    }
    ?>

    <form method="POST">
        <label>Nama Pasien:</label><br>
        <input type="text" name="nama_pasien" required><br><br>

        <label>Tanggal:</label><br>
        <input type="date" name="tanggal" required><br><br>

        <label>Keluhan:</label><br>
        <textarea name="keluhan" required></textarea><br><br>

        <label>Diagnosa:</label><br>
        <textarea name="diagnosa" required></textarea><br><br>

        <label>Obat:</label><br>
        <textarea name="obat" required></textarea><br><br>

        <input type="submit" value="Simpan">
    </form>

    <hr>

    <h3>Data Rekam Medis</h3>
    <table border="1" cellpadding="6" cellspacing="0">
        <tr>
            <th>No</th>
            <th>Nama Pasien</th>
            <th>Tanggal</th>
            <th>Keluhan</th>
            <th>Diagnosa</th>
            <th>Obat</th>
        </tr>
        <?php
        $query = "
            SELECT rm.*, p.nama_pasien 
            FROM rekam_medis rm 
            JOIN pasien p ON rm.id_pasien = p.id_pasien
            ORDER BY rm.id_rekam DESC
        ";
        $result = $conn->query($query);
        $no = 1;
        while ($data = $result->fetch_assoc()):
        ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($data['nama_pasien']) ?></td>
                <td><?= $data['tanggal'] ?></td>
                <td><?= htmlspecialchars($data['keluhan']) ?></td>
                <td><?= htmlspecialchars($data['diagnosa']) ?></td>
                <td><?= htmlspecialchars($data['obat']) ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
